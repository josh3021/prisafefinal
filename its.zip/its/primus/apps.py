from django.apps import AppConfig


class PrimusConfig(AppConfig):
    name = 'primus'
